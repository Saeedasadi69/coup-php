const BASE_URL = 'https://sasadi.ir/coup/api';

let currentGameId = null;
let currentPlayerId = null; // ID کاربر فعلی

// ثبت‌نام کاربر
document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
        const response = await fetch(`${BASE_URL}/register.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        const result = await response.json();
        alert(result.message);
    } catch (error) {
        console.error('Error during registration:', error);
        alert('An error occurred during registration. Please try again.');
    }
});

// لاگین کاربر
document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    try {
        const response = await fetch(`${BASE_URL}/login.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        const result = await response.json();
        if (result.status === 'success') {
            // فرض کنید سرور ID کاربر رو هم برمی‌گردونه
            currentPlayerId = result.player_id; // تنظیم ID کاربر فعلی
            document.getElementById('playerName').innerText = username;
            document.getElementById('registerForm').style.display = 'none';
            document.getElementById('loginForm').style.display = 'none';
            document.getElementById('gameSection').style.display = 'block';
        } else {
            alert(result.message);
        }
    } catch (error) {
        console.error('Error during login:', error);
        alert('An error occurred during login. Please try again.');
    }
});

// شروع بازی
document.getElementById('startGame').addEventListener('click', async () => {
    const response = await fetch(`${BASE_URL}/game.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'start', player_id: currentPlayerId })
    });

    const result = await response.json();
    if (result.status === 'success') {
        currentGameId = result.game_id;
        document.getElementById('gameStatus').innerText = result.message;
        updateGameStatus();
    } else {
        alert(result.message);
    }
});

// به‌روزرسانی وضعیت بازی
async function updateGameStatus() {
    if (!currentGameId) return;

    const response = await fetch(`${BASE_URL}/game.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'get_status', game_id: currentGameId, player_id: currentPlayerId })
    });

    const result = await response.json();
    if (result.status === 'success') {
        const game = result.game;
        if (game.status === 'in_progress') {
            document.getElementById('gameStatus').innerText = `
                Your Cards: ${game.player_cards.join(', ')}
                Game Status: ${game.status}
            `;
        } else {
            document.getElementById('gameStatus').innerText = 'Waiting for another player...';
        }
    } else {
        alert(result.message);
    }
}

// ارسال حرکت
document.getElementById('makeMove').addEventListener('click', async () => {
    if (!currentGameId) {
        alert('Please start a game first!');
        return;
    }

    const move = 'collect_coins'; // حرکت مورد نظر

    const response = await fetch(`${BASE_URL}/game.php`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'move', game_id: currentGameId, player_id: currentPlayerId, move })
    });

    const result = await response.json();
    alert(result.message);
});