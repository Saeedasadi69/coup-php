<?php
require 'db.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $action = $data['action'];

    if ($action === 'start') {
        // شروع بازی
        $player_id = $data['player_id']; // ID کاربری که بازی رو شروع کرده

        // بررسی اینکه آیا بازی در حال انتظار وجود داره یا نه
        $stmt = $pdo->prepare("SELECT * FROM games WHERE status = 'waiting' LIMIT 1");
        $stmt->execute();
        $waiting_game = $stmt->fetch();

        if ($waiting_game) {
            // اگر بازی در حال انتظار وجود داشت، کاربر دوم رو به بازی اضافه کن
            $game_id = $waiting_game['id'];
            $stmt = $pdo->prepare("UPDATE games SET player2_id = ?, status = 'in_progress' WHERE id = ?");
            $stmt->execute([$player_id, $game_id]);

            // اختصاص کارت‌ها به بازیکنان
            $cards = ['Duke', 'Assassin', 'Contessa', 'Captain', 'Ambassador'];
            shuffle($cards);

            $player1_cards = json_encode([$cards[0], $cards[1]]);
            $player2_cards = json_encode([$cards[2], $cards[3]]);

            $stmt = $pdo->prepare("UPDATE games SET player1_cards = ?, player2_cards = ? WHERE id = ?");
            $stmt->execute([$player1_cards, $player2_cards, $game_id]);

            echo json_encode(['status' => 'success', 'message' => 'Game started with another player!', 'game_id' => $game_id]);
        } else {
            // اگر بازی در حال انتظار وجود نداشت، بازی جدید ایجاد کن
            $stmt = $pdo->prepare("INSERT INTO games (player1_id, status) VALUES (?, 'waiting')");
            $stmt->execute([$player_id]);
            $game_id = $pdo->lastInsertId();
            echo json_encode(['status' => 'success', 'message' => 'Waiting for another player...', 'game_id' => $game_id]);
        }
    } elseif ($action === 'move') {
        // ثبت حرکت بازیکن
        $game_id = $data['game_id'];
        $player_id = $data['player_id'];
        $move = $data['move'];

        // ثبت حرکت در جدول moves
        $stmt = $pdo->prepare("INSERT INTO moves (game_id, player_id, action) VALUES (?, ?, ?)");
        $stmt->execute([$game_id, $player_id, $move]);

        echo json_encode(['status' => 'success', 'message' => 'Move recorded']);
    } elseif ($action === 'get_status') {
        // دریافت وضعیت بازی
        $game_id = $data['game_id'];
        $player_id = $data['player_id']; // ID بازیکن فعلی

        $stmt = $pdo->prepare("SELECT * FROM games WHERE id = ?");
        $stmt->execute([$game_id]);
        $game = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($game) {
            // تعیین اینکه بازیکن فعلی Player 1 هست یا Player 2
            $is_player1 = ($game['player1_id'] == $player_id);
            $is_player2 = ($game['player2_id'] == $player_id);

            if (!$is_player1 && !$is_player2) {
                echo json_encode(['status' => 'error', 'message' => 'You are not part of this game']);
                return;
            }

            // کارت‌های بازیکن فعلی
            $player_cards = $is_player1 ? json_decode($game['player1_cards'], true) : json_decode($game['player2_cards'], true);

            // وضعیت بازی (بدون نمایش کارت‌های حریف)
            echo json_encode([
                'status' => 'success',
                'game' => [
                    'player_cards' => $player_cards,
                    'status' => $game['status']
                ]
            ]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Game not found']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
    }
}
?>